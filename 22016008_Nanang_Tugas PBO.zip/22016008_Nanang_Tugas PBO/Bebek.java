class Bebek {
	private static String jenis_unggas = "Bebek";
	
	private static int jumlah_kaki = 2;
	
	public static String getJenisUnggas(){
		 return jenis_unggas;
		}
		
	public static int getJumlahKaki(){
		 return jumlah_kaki; 
		}
		
	private static void mengkwek(){
		 System.out.println("Aku mengkwek");
		}
	
	private static void berlari(){
		 System.out.println("Aku berlari");
		}
		
	public static void main(String [] args){
		 System.out.println(String.format("jenis unggas: %s",getJumlahKaki()));
		 System.out.println(String.format("jumlah kaki: %s",getJumlahKaki()));
		 
		 mengkwek();
		 berlari();
	}
}
