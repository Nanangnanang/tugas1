class contoh {
}
